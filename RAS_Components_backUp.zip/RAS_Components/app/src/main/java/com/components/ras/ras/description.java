package com.components.ras.ras;

public class description {
     private String description;
    private boolean descriptionAvailable = false;

    public void setDescriptionAvailable(boolean descriptionAvailable) {
        this.descriptionAvailable = descriptionAvailable;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean getDescriptionAvailable() {
        return descriptionAvailable;
    }

    public String getDescription() {
        return this.description;
    }
}

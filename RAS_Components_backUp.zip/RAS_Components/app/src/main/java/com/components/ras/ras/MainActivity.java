package com.components.ras.ras;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, Dialog.dialogListener {
    ListView list;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    DatabaseReference mrootRef = FirebaseDatabase.getInstance().getReference();
    ArrayList<String> imgid;
    String description;
    ImageView image;
    ArrayList<String> item_names;
    ArrayList<String> quantity;
    ArrayList<String> uris;
    adapter adapter;
    int i;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

    int x;
    SearchView searchView;
    private static final int CONSTANT = 999990;
    private static final int CONSTANT2 = 500000;
    description description1 = new description();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        item_names = new ArrayList<>();
        quantity = new ArrayList<>();
        imgid = new ArrayList<>();

        final ProgressBar progressBar = findViewById(R.id.mprogressbar);
        adapter = new adapter(this, item_names, quantity, imgid);
        list = findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setTextFilterEnabled(true);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        if (user == null) {
            Intent intent = new Intent(MainActivity.this, login.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

        }

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setUsername();
            }
        });
        mrootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                uris = new ArrayList<>();
                for (final DataSnapshot postSnapshot : snapshot.getChildren()) {
                    String value = Objects.requireNonNull(postSnapshot.child("Quantity").getValue()).toString();
                    String imageUri = Objects.requireNonNull(postSnapshot.child("image id").getValue()).toString();

                    final String item_name = postSnapshot.getKey();
                    imgid.add(imageUri);
                    quantity.add(value);
                    if (item_name == "ultrasonic"){
                        description1.setDescription(description);
                        description1.setDescriptionAvailable(true);}

                    item_names.add(item_name);
                }


                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError firebaseError) {
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        TextView navEmail = headerView.findViewById(R.id.emailNavHeader);
        final TextView navUsername = headerView.findViewById(R.id.nameNavHeader);
        image = headerView.findViewById(R.id.imageView);
        navEmail.setText(user.getEmail());
        if (user.getDisplayName() != null) {
            navUsername.setText(user.getDisplayName());
        }
        if (user.getPhotoUrl() != null) {
            String uri = user.getPhotoUrl().toString();
            loadImageFromUri(uri);
        }
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, view_item.class);
                intent.putExtra("image", imgid.get(position));
                intent.putExtra("text", item_names.get(position));
                intent.putExtra("quantity", quantity.get(position));
                intent.putExtra("description",description1.getDescription());
                ActivityOptionsCompat options = ActivityOptionsCompat.
                        makeSceneTransitionAnimation(MainActivity.this, Pair.create(findViewById(position + CONSTANT), "tImage"), Pair.
                                create(findViewById(position + CONSTANT2), "tText"));
                startActivity(intent, options.toBundle());


            }
        });


    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem item = menu.findItem(R.id.menuSearch);
        searchView = (SearchView) item.getActionView();
        searchView.setQueryHint("Search");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Toast.makeText(this, "لا هوا حلو كده متغيرش حاجة", Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.setUsername) {
        } else if (id == R.id.signOut) {
            FirebaseAuth.getInstance().signOut();
            finish();
            Intent intent = new Intent(MainActivity.this, login.class);
            startActivity(intent);
        } else if (id == R.id.nav_slideshow) {
        } else if (id == R.id.nav_manage) {
            Toast.makeText(this, "Developer of this app had a headache when he started making this section", Toast.LENGTH_LONG).show();

        } else if (id == R.id.nav_share) {
            Toast.makeText(this, "what a spy!", Toast.LENGTH_LONG).show();
        } else if (id == R.id.nav_send) {
            Toast.makeText(this, "What exactly are you trying to send here?", Toast.LENGTH_LONG).show();

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void setUsername() {
        Dialog f = new Dialog();
        f.show(getSupportFragmentManager(), "example dialog");


    }

    private void loadImageFromUri(String uri) {
        Picasso.get().load(uri).into(image);
    }

    @Override
    public void applyTexts(String item, String Quantity, String imgId) {
        item_names.add(item);
        imgid.add("https://cdn0.iconfinder.com/data/icons/tiny-icons-1/100/tiny-15-512.png");
        DatabaseReference mRefChild = mrootRef.child(item).child("Quantity");
        mRefChild.setValue(Quantity);
        adapter.notifyDataSetChanged();
    }

   /* private void showimgs() {
        for (i = 0; i < item_names.size() - 1; i++) {
            StorageReference imageRef = storageRef.child("listView icons");
            StorageReference img = imageRef.child(item_names.get(i) + ".png");
            Log.e("faaaffa",item_names.get(i));
            img.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Log.e("uris",uri.toString());
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e("L error ely lya 9 sa3at", e.getCause() + "\n" + e.toString());
                }
            });
            Log.e("errrrrrrror", "Item at position " + i + " is " + imgid.get(i));

        }
        adapter.notifyDataSetChanged();
    }*/


}

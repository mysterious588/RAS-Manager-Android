package com.components.ras.ras;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class view_item extends AppCompatActivity {
    String itemsname;
    String imgid;
    
    int quantity;
    TextView name;
    ImageView img;
    Button request;
    SeekBar seekBar;
    int amount_requested;
    TextView textView;
    TextView descriptionTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_item);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorPrimary)); // Navigation bar the soft bottom of some phones like nexus and some Samsung note series
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark)); //status bar or the time bar at the top
        }
        descriptionTxt = findViewById(R.id.mDescription);
        Toolbar toolbar = findViewById(R.id.toolbar);
        String desc = getIntent().getStringExtra("description");
        setSupportActionBar(toolbar);
        name = findViewById(R.id.name);
        textView = findViewById(R.id.amount_requested);
        seekBar = findViewById(R.id.seekbar);
        img = findViewById(R.id.itemViewImage);
        itemsname = getIntent().getStringExtra("text");
        if (itemsname == "ultrasonic")
            descriptionTxt.setText(desc);
        imgid = getIntent().getStringExtra("image");
        name.setText(itemsname);
        Picasso.get().load(imgid).into(img);
        quantity = Integer.parseInt(getIntent().getExtras().get("quantity").toString());

        Log.e("quantity 2 ", Integer.toString(quantity));
        seekBar.setMax(quantity);
        textView.setText(0 + " /" + quantity);

        request = findViewById(R.id.requestItem);
        seekBar = findViewById(R.id.seekbar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                amount_requested = i;
                String f = Integer.toString(amount_requested);
                int max = seekBar.getMax();
                textView.setText(f + " /" + Integer.toString(max));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                String f = Integer.toString(amount_requested);
                textView.setText(f + " /" + Integer.toString(seekBar.getMax()));

            }
        });

        request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if (amount_requested == 0){
                Toast.makeText(view_item.this,"نورت يا فندم",Toast.LENGTH_SHORT).show();
            }
            }
        });
    }


}

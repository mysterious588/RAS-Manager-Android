package com.components.ras.ras;

import android.app.Activity;
import android.os.Build;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Locale;

public class adapter extends ArrayAdapter<item> {
    private ArrayList<item> constArrayList;
    private final Activity context;
    private ArrayList<item> itemname;
    private static final int CONSTANT = 999990;
    private static final int CONSTANT2 = 500000;
    int x = 0;

    public adapter(Activity context, ArrayList<item> itemname, ArrayList<item> constArrayList) {
        super(context, R.layout.list, itemname);
        this.context = context;
        this.itemname = itemname;
        constArrayList.addAll(this.itemname);
        this.constArrayList = constArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, View view, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView;
        item currentWord = getItem(position);
        rowView = inflater.inflate(R.layout.list, null, true);
        TextView txtTitle = rowView.findViewById(R.id.item);
        ImageView imageView = rowView.findViewById(R.id.icon);
        TextView extraText = rowView.findViewById(R.id.textView1);
        Picasso.get().load(currentWord.getImageId()).into(imageView);
        txtTitle.setText(currentWord.getName());
        extraText.setText(currentWord.getQuantity());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            txtTitle.setId(position + CONSTANT2);
            imageView.setId(position + CONSTANT);
            txtTitle.setTransitionName("tText");
            imageView.setTransitionName("tImage");
        }
        return rowView;

    }

    public void filter(String charText) {
        setConstArray();
        itemname.addAll(constArrayList);
        charText = charText.toLowerCase(Locale.getDefault());
        itemname.clear();
        if (charText.length() == 0) {
            itemname.addAll(constArrayList);
        } else {
            for (item model : constArrayList) {
                if (model.getName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    itemname.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }

    private void setConstArray() {
        x++;
        if (x == 1) constArrayList.addAll(itemname);
    }
}


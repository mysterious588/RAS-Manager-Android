package com.components.ras.ras;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.shashank.sony.fancytoastlib.FancyToast;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class view_item extends AppCompatActivity {
    String itemsname;
    String imgid;
    String description;
    int quantity;
    TextView name;
    ImageView img;
    Button request;
    SeekBar seekBar;
    int amount_requested;
    TextView textView;
    TextView descriptionTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_item);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.colorPrimary)); // Navigation bar the soft bottom of some phones like nexus and some Samsung note series
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark)); //status bar or the time bar at the top
        }
        descriptionTxt = findViewById(R.id.mDescription);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        name = findViewById(R.id.name);
        textView = findViewById(R.id.amount_requested);
        seekBar = findViewById(R.id.seekbar);
        img = findViewById(R.id.itemViewImage);
        itemsname = getIntent().getStringExtra("text");
        if (getIntent().getStringExtra("description") != null) {
            description = getIntent().getStringExtra("description");
            Log.e("found it", description);
            descriptionTxt.setText(description);
        }
        imgid = getIntent().getStringExtra("image");
        name.setText(itemsname);
        Picasso.get().load(imgid).into(img);
        quantity = Integer.parseInt(Objects.requireNonNull(Objects.requireNonNull(getIntent().getExtras()).get("quantity")).toString());

        Log.e("quantity 2 ", Integer.toString(quantity));
        seekBar.setMax(quantity);
        textView.setText(0 + " /" + quantity);
        Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setInterpolator(new DecelerateInterpolator()); //add this
        fadeIn.setDuration(1000);


        AnimationSet animation = new AnimationSet(false); //change to false
        animation.addAnimation(fadeIn);
        descriptionTxt.setAnimation(animation);
        request = findViewById(R.id.requestItem);
        seekBar = findViewById(R.id.seekbar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                amount_requested = i;
                String f = Integer.toString(amount_requested);
                int max = seekBar.getMax();
                textView.setText(String.format("%s /%s", f, Integer.toString(max)));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                String f = Integer.toString(amount_requested);
                textView.setText(String.format("%s /%s", f, Integer.toString(seekBar.getMax())));
            }
        });

        request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (amount_requested == 0)
                    FancyToast.makeText(view_item.this, "ما تختار حاجة يعم", FancyToast.LENGTH_SHORT,FancyToast.ERROR,false).show();

            }
        });
    }


}
